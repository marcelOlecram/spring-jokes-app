package guru.springframework.services;

public interface JokeService {
    String getChuckNorrisJoke();
}
